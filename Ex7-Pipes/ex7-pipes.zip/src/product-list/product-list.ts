import { Component } from '@angular/core';

@Component({
  selector: 'app-product-list',
  imports: [],
  templateUrl: './product-list.html',
  styleUrl: './product-list.css',
})
export class ProductList {
  protected title = 'Product List';
  protected products = [
    {
      imagePreview: 'assets/images/shovel.jpeg',
      code: '1',
      name: 'Golden Shovel',
      unitPrice: '$19.95',
      releaseDate: 'March 19, 2021',
      rating:3
    },
    {
      imagePreview: 'assets/images/tractor.jpeg',
      code: '2',
      name: 'Tractor',
      unitPrice: '$4000.95',
      releaseDate: 'March 19, 2021',
      rating:3
    },
    {
      imagePreview: 'assets/images/workbench.jpeg',
      code: '3',
      name: 'Workbench',
      unitPrice: '$400.95',
      releaseDate: 'March 19, 2021',
      rating:3
    }
  ];
}
